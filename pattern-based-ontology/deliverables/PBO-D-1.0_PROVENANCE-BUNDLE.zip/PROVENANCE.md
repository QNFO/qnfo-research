# Provenance Manifest — 42 Theses on the Nature of a Pattern-Based Reality v3.0

## Chain of Custody

1. **Research conducted:** 2026-07-16
2. **Agent:** QNFO Research Agent (DeepSeek v4 Pro)
3. **Conversation exported:** 2026-07-16T08:30:00Z
4. **Zenodo deposition:** 10.5281/zenodo.21310808 (new version — DOI assigned after upload)

## Bundle Contents

| File | Description |
|:-----|:------------|
| `conversation.md` | Full LLM-agent conversation history (session index) |
| `session-metadata.json` | Agent, model, timestamps, git state |
| `project-files/` | Complete project filesystem snapshot |
| `git-state.txt` | Git log and status at publication time |
| `PROVENANCE.md` | This manifest |
| `README.md` | Human-readable entry point |

## Reproducibility Notes

- The conversation history records every prompt, tool invocation, and agent response.
- The project filesystem snapshot preserves all working scripts and data.
- Together, these enable independent verification of the research process.
- The final paper (`42-theses-v3.0-expanded.md` and `42-theses-v3.0-expanded.pdf`) are uploaded separately alongside this bundle.

## Calibration

This v3.0 of the 42 Theses was calibrated per QNFO-POL-COM-001 (Research Integrity Mandate):
- All 42 theses tagged with certainty labels ([my conjecture], [speculative], [not yet falsifiable], [PHILOSOPHY])
- Epistemic Note with ontological status and Map/Territory distinction
- Cross-references to 7 calibrated successor publications (DOIs)
- Limitations & Open Questions section added
- Falsifiability statements on empirical claims

## Verification

To verify this research:
1. Read `conversation.md` to understand the research dialogue
2. Examine `project-files/` for all working code and data
3. Cross-reference claims in the paper against the conversation and code
4. Check the Zenodo record at https://doi.org/10.5281/zenodo.21310808 for all versions
