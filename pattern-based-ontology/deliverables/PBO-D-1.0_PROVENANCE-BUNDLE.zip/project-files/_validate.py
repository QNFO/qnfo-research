"""Run all pre-publication quality gates on the expanded 42 Theses v3.0."""
import os, re, sys, json

md_path = r"C:\Users\LENOVO\Desktop\42-theses-workdir\42-theses-v3.0-expanded.md"
with open(md_path, 'r', encoding='utf-8') as f:
    text = f.read()

results = {}

# 1. Publication Language Gate
banned_terms = ["Module N", "Task N", "SPRINT", "PROCEED", "RESUME",
    "PROJECT STATE", "0.N.py", "0.N.md", "cp1252",
    "ready for handoff", "new agent starting from cold"]
hits = {term: text.count(term) for term in banned_terms if term in text}
results["language_gate"] = {"passed": len(hits) == 0, "violations": hits}

# 2. Author block present
results["author_block"] = {
    "passed": "Rowan Brad Quni-Gudzinas" in text and "2026-07-16" in text and "QNFO-ULA" in text
}

# 3. Math in LaTeX delimiters
bare_math_chars = ['\u03b1', '\u03b2', '\u03b3', '\u03b4', '\u03b5', '\u03c0', '\u03c3', '\u221e', '\u2211', '\u222b', '\u221a', '\u2264', '\u2265', '\u2260']
bare_hits = [c for c in bare_math_chars if c in text]
results["math_format"] = {"passed": len(bare_hits) == 0, "violations": bare_hits}

# 4. Citations present (support hyphens in citekeys)
citations = re.findall(r'\[@[\w-]+(?:[,;\s]+@[\w-]+)*\]', text)
results["citations"] = {"count": len(citations), "passed": len(citations) > 0}

# 5. Certainty labels
paragraphs = [p for p in text.split('\n\n') if len(p.strip()) > 100]
certainty_labels = ['[established]', '[speculative]', '[my conjecture]', '[debated]',
    '[mainstream interpretation]', '[not yet falsifiable]', '[PHILOSOPHY]',
    '[LLM-INFERRED]']
labeled = sum(1 for p in paragraphs if any(lbl in p for lbl in certainty_labels))
label_ratio = labeled / max(len(paragraphs), 1)
results["certainty_labels"] = {
    "count": labeled, "total_paragraphs": len(paragraphs),
    "ratio": round(label_ratio, 3), "passed": label_ratio >= 0.05
}

# 6. Cross-references
doi_pattern = re.findall(r'10\.5281/zenodo\.\d+', text)
results["cross_references"] = {
    "count": len(set(doi_pattern)),
    "dois": list(set(doi_pattern)),
    "passed": len(set(doi_pattern)) >= 3
}

all_passed = all(v["passed"] for v in results.values())
results["overall"] = "PASS" if all_passed else "FAIL"

# Print results
for gate, result in results.items():
    if gate == "overall":
        print(f"\n{'='*50}")
        print(f"OVERALL: {result}")
    elif isinstance(result, dict) and "passed" in result:
        status = "PASS" if result["passed"] else "FAIL"
        detail = ""
        if gate == "certainty_labels":
            detail = f" ({result['count']}/{result['total_paragraphs']} paragraphs, ratio={result['ratio']})"
        elif gate == "cross_references":
            detail = f" ({result['count']} unique DOIs)"
        elif gate == "citations":
            detail = f" ({result['count']} citations)"
        print(f"[{status}] {gate}{detail}")
        if not result["passed"] and "violations" in result:
            print(f"  Violations: {result['violations']}")

sys.exit(0 if all_passed else 1)
