# Provenance Manifest — Pattern-Based Ontology v1.0

## Chain of Custody

1. **Research conducted:** 2026-07-16
2. **Agent:** QNFO Research Agent (DeepSeek v4 Pro)
3. **Session ID:** C7emX3HLc7Ns8kdud5tU6
4. **Zenodo deposition:** Pending (DOI assigned after upload)

## Bundle Contents

| File | Description |
|:-----|:------------|
| `conversation.md` | Full LLM-agent conversation history (session index) |
| `session-metadata.json` | Agent, model, timestamps, git state |
| `project-files/` | Complete project filesystem snapshot |
| `git-state.txt` | Working environment state at publication time |
| `PROVENANCE.md` | This manifest |
| `README.md` | Human-readable entry point |

## Reformulation Context

This document reformulates the entire Autaxys research program (2025–2026) as a **Pattern-Based Ontology** grounded in Spencer-Brown's Laws of Form. The key changes:
- "Autaxys generative engine" → Recursive distinction-making
- "Ontological Closure" → Pattern stability through distinction closure
- "Autaxic Quantum Numbers" → Normal form properties in the Syntactic Token Calculus
- Adds explicit grounding in Laws of Form (mark, enclosure, Calling, Crossing)
- Eliminates teleological language ("drive toward") in favor of mechanistic recursion

## Cross-Referenced Publications

This work reformulates and supersedes:
- 42 Theses v3.0 (10.5281/zenodo.21389470)
- The Resonant Universe v2.0.1 (10.5281/zenodo.21194864)
- Mass-Frequency Identity v3.2.0 (10.5281/zenodo.21360549)
- Autaxic Table of Patterns v2.0 (10.5281/zenodo.21369319)
- Autaxys Ontological Status Addendum v1.0 (10.5281/zenodo.21369303)
- Autaxys Master Plan v3.0 (10.5281/zenodo.21369313)

## Verification

To verify this research:
1. Read `conversation.md` to understand the research dialogue
2. Examine `project-files/` for all working code and data
3. Cross-reference claims in the paper against the conversation and code
